import cv2
import numpy as np
import torch
from torch.utils.data import Dataset

class RoadDataset(Dataset):
    def __init__(self, image_paths):
        self.image_paths = image_paths

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img = cv2.imread(self.image_paths[idx])
        img = cv2.resize(img, (256, 256))

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        lower = np.array([0, 0, 50])
        upper = np.array([180, 50, 200])

        mask = cv2.inRange(hsv, lower, upper)

        h, w = mask.shape
        mask[:h//2, :] = 0

        kernel = np.ones((5,5), np.uint8)

        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        img = img / 255.0
        mask = mask / 255.0

        img = torch.tensor(img).permute(2,0,1).float()
        mask = torch.tensor(mask).unsqueeze(0).float()

        return img, mask