import os
import cv2
import numpy as np

# folder path
folder_path = "/Users/aneeq/Downloads/v1.0-mini/samples/CAM_FRONT/"

image_paths = []

for file in os.listdir(folder_path):
    if file.endswith(".jpg"):
        image_paths.append(os.path.join(folder_path, file))

print("Total images:", len(image_paths))

# 🔥 TEST ON ONE IMAGE
image_path = image_paths[0]  # take first image

img = cv2.imread(image_path)
img = cv2.resize(img, (256, 256))

hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

lower = np.array([0, 0, 50])
upper = np.array([180, 50, 200])

mask = cv2.inRange(hsv, lower, upper)

h, w = mask.shape
mask[:h//2, :] = 0

cv2.imwrite("output_image.png", img)
cv2.imwrite("output_mask.png", mask)

print("Saved test output!")