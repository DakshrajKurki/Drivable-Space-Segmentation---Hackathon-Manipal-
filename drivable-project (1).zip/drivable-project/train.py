import torch
from torch.utils.data import DataLoader
import torch.nn as nn
import torch.optim as optim
import os

from dataset import RoadDataset
from model import UNet

# path to your images
folder_path = "/Users/aneeq/Downloads/v1.0-mini/samples/CAM_FRONT"

image_paths = []
for file in os.listdir(folder_path):
    if file.endswith(".jpg"):
        image_paths.append(os.path.join(folder_path, file))

print("Total images:", len(image_paths))

# dataset + dataloader
dataset = RoadDataset(image_paths)
dataloader = DataLoader(dataset, batch_size=8, shuffle=True)

# model
model = UNet()

# loss + optimizer
criterion = nn.BCEWithLogitsLoss()
optimizer = optim.Adam(model.parameters(), lr=0.0005)

# training loop
epochs = 20

for epoch in range(epochs):
    total_loss = 0

    for imgs, masks in dataloader:
        outputs = model(imgs)

        loss = criterion(outputs, masks)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    print(f"Epoch {epoch+1}, Loss: {total_loss:.4f}")

# save model
torch.save(model.state_dict(), "model.pth")

print("Training complete!")