import torch
import cv2
import numpy as np

from model import UNet

# load model
model = UNet()
model.load_state_dict(torch.load("model.pth"))
model.eval()

# test image
import os

folder_path = "/Users/aneeq/Downloads/v1.0-mini/samples/CAM_FRONT/"
files = sorted(os.listdir(folder_path))

for file in files[:10]:   # 👈 only 10 images
    if file.endswith(".jpg"):

        image_path = os.path.join(folder_path, file)

        img = cv2.imread(image_path)
        img = cv2.resize(img, (256, 256))

        input_img = img / 255.0
        input_img = torch.tensor(input_img).permute(2,0,1).unsqueeze(0).float()

        with torch.no_grad():
            output = model(input_img)

        mask = output.squeeze().numpy()
        mask = (mask > 0.3).astype(np.uint8) * 255

        # clean
        kernel = np.ones((7,7), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        h, w = mask.shape
        mask[:int(h*0.6), :] = 0

        # overlay
        overlay = img.copy()
        overlay[mask == 255] = [0, 255, 0]
        final = cv2.addWeighted(img, 0.7, overlay, 0.3, 0)

        name = file.split(".")[0]

        cv2.imwrite(f"outputs/input_{name}.png", img)
        cv2.imwrite(f"outputs/mask_{name}.png", mask)
        cv2.imwrite(f"outputs/output_{name}.png", final)    

print("Done!")


