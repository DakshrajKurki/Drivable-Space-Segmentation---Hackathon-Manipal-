import torch
import torch.nn as nn

class UNet(nn.Module):
    def __init__(self):
        super().__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 16, 3, padding=1),
            nn.ReLU(),
            nn.Conv2d(16, 16, 3, padding=1),
            nn.ReLU()
        )

        self.pool = nn.MaxPool2d(2)

        self.conv2 = nn.Sequential(
            nn.Conv2d(16, 32, 3, padding=1),
            nn.ReLU(),
            nn.Conv2d(32, 32, 3, padding=1),
            nn.ReLU()
        )

        self.up = nn.ConvTranspose2d(32, 16, 2, stride=2)

        self.conv3 = nn.Sequential(
            nn.Conv2d(32, 16, 3, padding=1),
            nn.ReLU(),
            nn.Conv2d(16, 16, 3, padding=1),
            nn.ReLU()
        )

        self.final = nn.Conv2d(16, 1, 1)

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.pool(x1)

        x3 = self.conv2(x2)

        x4 = self.up(x3)
        x5 = torch.cat([x4, x1], dim=1)

        x6 = self.conv3(x5)

        return self.final(x6)